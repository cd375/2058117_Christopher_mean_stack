// this page is for interfaces

// creates a clothes interface to specify what is in the class


// stores funcions
export interface StoreFun{
    getValues():any;
    writeTable(type:string,price:number):any;
    fillCart():any;

}
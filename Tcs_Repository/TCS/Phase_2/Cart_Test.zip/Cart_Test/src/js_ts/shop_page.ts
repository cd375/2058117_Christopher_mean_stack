// focus on connections
import {Clothes} from "./cart_fun"


// this page will display shoping
// need to call let call = new clothes(get type, getprice)
// get by id

/* const ex = `hello`
const dum: number = 2
const shoppingPage:string = ` <!--write out the page lay out with dummy variables start here--><div class="container-fluid"> <nav class="navbar navbar-light bg-light"><a class="navbar-brand" href="#"><h1 class="display-3">myShoppingSite</h1></a><ul class="nav nav-pills">                   <li class="navbar-item ">
                        <a href="#" class= "nav-link disabled" >cart size : then the size is displayed here</a>
                    </li>
                    <li class="navbar-item active ">
                        <a href="cart.html" class="nav-link"> Checkout</a>
                    </li>
                </ul>
        </nav>

        <div class="wrapper">
                <form action="" class="form-group">
                    <div class="row p-2 ">

                        <div class="col-6 p-2">
                            <div class="row ">
                                <div class="col-12 ">
                                    <img class="img-fluid"  src="https://www.pacsun.com/dw/image/v2/AAJE_PRD/on/demandware.static/-/Sites-pacsun_storefront_catalog/default/dwb2b66880/product_images/0126468680167NEW_01_065.jpg?sw=458&sh=710&sm=fit" alt="">
                                    <br>
                                </div>
                                <div class="col-12">
                                    <small><b>Red shrit</b></small><br>

                                </div>
                                <div class="col-12">
                                    <small class="lead">$ 20 </small><br>
                                </div>
                                <div class="col-12">
                                    <input type="button" id="r-shirt" value="Add to cart" class="btn btn-primary">
                                </div>
                            </div>

                        </div>
                        <div class="col-6 p-2  ">
                            <div class="row">
                                <div class="col-12">
                                    <img class="img-fluid"  src="https://www.pacsun.com/dw/image/v2/AAJE_PRD/on/demandware.static/-/Sites-pacsun_storefront_catalog/default/dw8eb8dc7c/product_images/0133491920057NEW_01_001.jpg?sw=458&sh=710&sm=fit" alt="">
                                    <br>
                                </div>
                                <div class="col-12">                                        <small><b>Black pants</b></small>
                                        <br>

                                </div>
                                <div class="col-12">

                                    <small class="lead">$ 60 </small><br>

                                </div>
                                <div class="col-12">
                                    <input type="button" id="b-pants" value="Add to cart" class="btn btn-primary">
                                </div>
                            </div>

                        </div>
                        <div class="col-6 p-2">
                            <div class="row">
                                <div class="col-12">
                                    <img class="img-fluid"  src="https://www.pacsun.com/dw/image/v2/AAJE_PRD/on/demandware.static/-/Sites-pacsun_storefront_catalog/default/dw326b5219/product_images/0120468680027NEW_01_051.jpg?sw=458&sh=710&sm=fit" alt="">
                                    <br>
                                </div>
                                <div class="col-12">

                                    <small><b>Blue Shirt</b></small><br>

                                </div>
                                <div class="col-12">
                                    <small class="lead">$ 20 </small><br>
                                </div>
                                <div class="col-12">
                                    <input type="button" id="b-shirt" value="Add to cart" class="btn btn-primary">
                                </div>
                            </div>
                        </div>
                        <div class="col-6 p-2 ">
                            <div class="row">
                                <div class="col-12">
                                    <img class="img-fluid"  src="https://www.pacsun.com/dw/image/v2/AAJE_PRD/on/demandware.static/-/Sites-pacsun_storefront_catalog/default/dw55a3d097/product_images/0130250500071NEW_01_010.jpg?sw=458&sh=710&sm=fit" alt="">
                                    <br>
                                </div>
                                <div class="col-12">

                                    <small><b>Designer Pants</b></small><br>

                                </div>
                                <div class="col-12">
                                    <small class="lead">$ 200 </small><br>
                                </div>
                                <div class="col-12">
                                    <input type="button" id="d-pants" value="Add to cart" class="btn btn-primary">
                                </div>
                            </div>

                        </div>
                    </div>

                </form>

            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    ` */
 // const bodyTag = document.getElementById("shopBody") as HTMLDivElement
 // bodyTag.textContent= shoppingPage;
// document.write(shoppingPage)

/*
const desPants = (document.getElementById("d-pants") as HTMLElement);

// event listeners for click
if(document.getElementById("r-shirt") as HTMLElement != null){
    const redShirt = (document.getElementById("r-shirt") as HTMLElement)
    redShirt?.addEventListener('click',isRedShirt())
}
if(document.getElementById("b-pants") as HTMLElement != null){
    const blackPants = (document.getElementById("b-pants") as HTMLElement);
    blackPants?.addEventListener('click',isBlackPants())

}
if(document.getElementById("b-shirt") as HTMLElement != null){
    const blueShirt = (document.getElementById("b-shirt") as HTMLElement);
    blueShirt?.addEventListener('click',isBlueShrit())

}
if(document.getElementById("d-pants") as HTMLElement != null){
    const desPants = (document.getElementById("d-pants") as HTMLElement);
    desPants.addEventListener('click',isDesPants())

} */
/* const testme =  document.querySelector('#r-shirt') as HTMLButtonElement
 function test ():any {
    if (testme){
        // testThing = document.querySelector("#r-shirt") as HTMLButtonElement
        console.log("good")
        return testme

    }else{
        // const testThing = document.querySelector("#r-shirt") as HTMLButtonElement
        return testme
    }
}

console.log("test console")
if(test() == null){
    console.log("do not want to showtest console in if  "+test())
}
console.log("test console out of if  "+test())
 */
let i = 0

    if(localStorage.getItem("shopObj")){

        // get from localstorage
        const localShop:any = localStorage.getItem("shopObj");

        // parse information
        const shopJson:any = JSON.parse(localShop)
        console.log(shopJson.length)

        if((document.getElementById("cartSize") as HTMLLIElement)){

            document.addEventListener("DOMContentLoaded",()=>{
                (document.querySelector("button") as HTMLButtonElement).addEventListener("click",(ev:Event):any => {
                    ev.preventDefault()
                    i++
                    const cartS = document.getElementById("cartSize") as HTMLLIElement
                    cartS.innerText = "Cart Size: " + shopJson.length;
                    console.log("this is i  "+ i)
                    console.log("table test"+cartS.innerText)
                } )
            });
        }
    }




if(document.getElementById("r-shirt")as HTMLButtonElement){
    document.addEventListener("DOMContentLoaded",()=>{
        (document.getElementById("r-shirt") as HTMLButtonElement).addEventListener("click",(ev:Event):any => {
            ev.preventDefault();
            const RType:string = "Red Shirt"
            const RPrice:number = 20
            const redClothes = new Clothes(RType,RPrice)
            redClothes.getValues()

        } )
    });
    const test = (document.getElementById("r-shirt") as HTMLButtonElement)
    console.log ("check me   " +test)
}
if(document.getElementById("b-pants")as HTMLButtonElement){
    document.addEventListener("DOMContentLoaded",()=>{
        (document.getElementById("b-pants") as HTMLButtonElement).addEventListener("click",(ev:Event):any => {
            ev.preventDefault();
            const bpType:string = "Black Pants"
            const bpPrice:number = 60
            const blackClothes = new Clothes(bpType,bpPrice)
            blackClothes.getValues()

        } )
    });
}
if(document.getElementById("b-shirt")as HTMLButtonElement){
    document.addEventListener("DOMContentLoaded",()=>{
        (document.getElementById("b-shirt") as HTMLButtonElement).addEventListener("click",(ev:Event):any => {
            ev.preventDefault();
            const bsType:string = "Blue Shirt"
            const bsPrice:number = 20
            const blueClothes = new Clothes(bsType,bsPrice)
             blueClothes.getValues()


        } )
    });
}
if(document.getElementById("d-pants")as HTMLButtonElement){
    document.addEventListener("DOMContentLoaded",()=>{
        (document.getElementById("d-pants") as HTMLButtonElement).addEventListener("click",(ev:Event):any => {
            ev.preventDefault();
            const dType:string = "Designer Pants"
            const dPrice:number = 200
            const desClothes = new Clothes(dType,dPrice)
             desClothes.getValues()

        } )
    });
}

// fuction to get price and type
/*  function isRedShirt ():any {
    const RType:string = "Red Shirt"
    const RPrice:number = 20
    const redClothes = new Clothes(RType,RPrice)
    redClothes.getValues()
}
function isBlackPants ():any {
    const bpType:string = "Black Pants"
    const bpPrice:number = 60
    const blackClothes = new Clothes(bpType,bpPrice)
    blackClothes.getValues()


}
function isBlueShrit ():any {
    const bsType:string = "Blue Shirt"
    const bsPrice:number = 20
    const blueClothes = new Clothes(bsType,bsPrice)
     blueClothes.getValues()


}
function isDesPants():any {
    const dType:string = "Designer Pants"
    const dPrice:number = 200
    const desClothes = new Clothes(dType,dPrice)
     desClothes.getValues()

} */

// document.write(shoppingPage)
// (document.getElementById("r-shirt") as HTMLElement).innerHTML = shoppingPage;
export interface FormatQ {
    qNumber:any, 
    question:any,
     AnsA:any,
     AnsB:any ,
     AnsC:any ,
     AnsD:any ,

}

export interface FormatQA {
    qNumber:any, 
    question:any,
     AnsA:any,
     AnsB:any ,
     AnsC:any ,
     AnsD:any ,
     RightAns: any
}

